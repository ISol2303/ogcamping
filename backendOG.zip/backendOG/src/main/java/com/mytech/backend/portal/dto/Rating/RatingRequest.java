package com.mytech.backend.portal.dto.Rating;

public record RatingRequest(Integer rating, String feedback) {}
