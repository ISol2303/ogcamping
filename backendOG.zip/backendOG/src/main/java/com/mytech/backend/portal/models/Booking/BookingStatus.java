package com.mytech.backend.portal.models.Booking;

public enum BookingStatus { PENDING, CONFIRMED, IN_PROGRESS, CANCELLED, COMPLETED }