package com.mytech.backend.portal.dto.Combo;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ComboServiceDTO {
    private Long serviceId;
    private Integer quantity;
}