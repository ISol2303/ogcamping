package com.mytech.backend.portal.models.Booking;

public enum ItemType {
    SERVICE, COMBO, EQUIPMENT
}
