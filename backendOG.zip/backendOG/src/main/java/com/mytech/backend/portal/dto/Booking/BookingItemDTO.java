package com.mytech.backend.portal.dto.Booking;

import java.time.LocalDate;

public record BookingItemDTO(
        Long bookingItemId,
        Integer quantity,
        Double price,
        LocalDate checkInDate,
        LocalDate checkOutDate
) {}