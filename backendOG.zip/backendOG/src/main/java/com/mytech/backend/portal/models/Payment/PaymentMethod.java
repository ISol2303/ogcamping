package com.mytech.backend.portal.models.Payment;

public enum PaymentMethod { VNPAY, MOMO, PAYPAL }