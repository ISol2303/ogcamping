package com.mytech.backend.portal.dto.Booking;

import java.time.LocalDate;
import java.util.List;

public record BookingGetByServiceDTO(
        Long bookingId,
        String customerName,
        LocalDate checkInDate,
        LocalDate checkOutDate,
        Integer numberOfPeople,
        String status,
        List<BookingItemDTO> items
) {}