package com.mytech.backend.portal.models.Payment;


public enum PaymentStatus { PENDING, PAID, FAILED, REFUNDED, CANCELLED }