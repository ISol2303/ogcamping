package com.mytech.backend.portal.dto.Wishlist;
import lombok.*;

@Data
public class WishlistAddRequest {
    private Long userId;
}

