package com.mytech.backend.portal.models.Service;

public enum ServiceTag {
    POPULAR,    // Phổ biến
    NEW,        // Mới
    DISCOUNT    // Ưu đãi
}
