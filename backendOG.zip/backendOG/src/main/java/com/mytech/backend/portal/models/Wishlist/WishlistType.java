package com.mytech.backend.portal.models.Wishlist;

public enum WishlistType {
    SERVICE, COMBO
}